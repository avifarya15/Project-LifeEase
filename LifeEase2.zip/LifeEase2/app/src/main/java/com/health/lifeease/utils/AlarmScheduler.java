package com.health.lifeease.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;
import com.health.lifeease.models.Reminder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AlarmScheduler {

    private static final String TAG = "AlarmScheduler";
    private Context context;
    private AlarmManager alarmManager;

    public AlarmScheduler(Context context) {
        this.context = context;
        this.alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    }

    // Jadwalkan alarm untuk reminder
    public void scheduleReminder(Reminder reminder) {
        try {
            // Parse tanggal dan waktu
            String dateTimeString = reminder.getDate() + " " + reminder.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
            Date date = sdf.parse(dateTimeString);

            if (date == null) {
                Log.e(TAG, "Failed to parse date");
                return;
            }

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            // Cek apakah waktu sudah lewat
            if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
                Toast.makeText(context, "Waktu pengingat sudah lewat!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Buat intent untuk AlarmReceiver
            Intent intent = new Intent(context, AlarmReceiver.class);
            intent.putExtra("reminder_id", reminder.getId());
            intent.putExtra("title", reminder.getTitle());
            intent.putExtra("message", reminder.getDescription());

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    reminder.getId(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Set alarm
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis(),
                        pendingIntent
                );
            } else {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis(),
                        pendingIntent
                );
            }

            Log.d(TAG, "Alarm scheduled for: " + dateTimeString);
            Toast.makeText(context, "Pengingat dijadwalkan!", Toast.LENGTH_SHORT).show();

        } catch (ParseException e) {
            Log.e(TAG, "Error parsing date: " + e.getMessage());
            Toast.makeText(context, "Format tanggal/waktu salah!", Toast.LENGTH_SHORT).show();
        }
    }

    // Batalkan alarm
    public void cancelReminder(int reminderId) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                reminderId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
        Log.d(TAG, "Alarm cancelled for reminder ID: " + reminderId);
    }

    // Jadwalkan notifikasi harian (setiap hari jam 8 pagi)
    public void scheduleDailyHealthTip() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 8);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        // Jika waktu sudah lewat hari ini, jadwalkan untuk besok
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("reminder_id", 9999);
        intent.putExtra("title", "Tips Kesehatan Hari Ini");
        intent.putExtra("message", "Mulai hari Anda dengan kebiasaan sehat!");

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                9999,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Set repeating alarm setiap hari
        alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY,
                pendingIntent
        );

        Log.d(TAG, "Daily health tip scheduled");
    }

    // Jadwalkan pengingat minum air (setiap 2 jam)
    public void scheduleWaterReminder() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 2);

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("reminder_id", 9998);
        intent.putExtra("title", "💧 Waktunya Minum Air!");
        intent.putExtra("message", "Jangan lupa minum air putih untuk hidrasi tubuh.");

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                9998,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Set repeating alarm setiap 2 jam
        alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                2 * 60 * 60 * 1000, // 2 jam dalam milidetik
                pendingIntent
        );

        Log.d(TAG, "Water reminder scheduled");
    }

    // Batalkan pengingat harian
    public void cancelDailyReminders() {
        // Batalkan daily health tip
        Intent intent1 = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent1 = PendingIntent.getBroadcast(
                context, 9999, intent1, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        alarmManager.cancel(pendingIntent1);

        // Batalkan water reminder
        Intent intent2 = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(
                context, 9998, intent2, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        alarmManager.cancel(pendingIntent2);

        Log.d(TAG, "Daily reminders cancelled");
    }
}