package com.health.lifeease.fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.health.lifeease.R;
import com.health.lifeease.adapters.HealthTipsAdapter;
import com.health.lifeease.adapters.ReminderAdapter;
import com.health.lifeease.models.HealthTip;
import com.health.lifeease.models.Reminder;
import com.health.lifeease.utils.AlarmScheduler;
import com.health.lifeease.utils.DatabaseHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class HomeFragment extends Fragment {

    private TextView tvGreeting, tvUsername, tvSwitchView, tvNoReminders;
    private ImageView ivAddReminder;
    private RecyclerView rvHealthTips, rvReminders;
    private HealthTipsAdapter healthTipsAdapter;
    private ReminderAdapter reminderAdapter;
    private DatabaseHelper databaseHelper;
    private AlarmScheduler alarmScheduler;
    private SharedPreferences sharedPreferences;
    private boolean isGridView = false;
    private int userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Inisialisasi
        databaseHelper = new DatabaseHelper(getContext());
        sharedPreferences = getActivity().getSharedPreferences("LifeEasePrefs", MODE_PRIVATE);
        userId = sharedPreferences.getInt("userId", -1);

        // Inisialisasi views
        tvGreeting = view.findViewById(R.id.tvGreeting);
        tvUsername = view.findViewById(R.id.tvUsername);
        tvSwitchView = view.findViewById(R.id.tvSwitchView);
        tvNoReminders = view.findViewById(R.id.tvNoReminders);
        ivAddReminder = view.findViewById(R.id.ivAddReminder);
        rvHealthTips = view.findViewById(R.id.rvHealthTips);
        rvReminders = view.findViewById(R.id.rvReminders);

        // Set greeting dan username
        setGreeting();
        tvUsername.setText(sharedPreferences.getString("username", "User"));

        // Setup Health Tips RecyclerView
        setupHealthTips();

        // Setup Reminders RecyclerView
        setupReminders();

        // Switch view click
        tvSwitchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isGridView = !isGridView;
                setupHealthTips();
                tvSwitchView.setText(isGridView ? "List View" : "Grid View");
            }
        });

        // Add reminder click
        ivAddReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddReminderDialog();
            }
        });

        return view;
    }

    private void setGreeting() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        if (hour < 12) {
            tvGreeting.setText(R.string.greeting_morning);
        } else if (hour < 18) {
            tvGreeting.setText(R.string.greeting_afternoon);
        } else {
            tvGreeting.setText(R.string.greeting_evening);
        }
    }

    private void setupHealthTips() {
        List<HealthTip> healthTips = new ArrayList<>();
        healthTips.add(new HealthTip(getString(R.string.tip_water), getString(R.string.tip_water_desc), R.drawable.ic_water, R.color.water));
        healthTips.add(new HealthTip(getString(R.string.tip_exercise), getString(R.string.tip_exercise_desc), R.drawable.ic_exercise, R.color.steps));
        healthTips.add(new HealthTip(getString(R.string.tip_sleep), getString(R.string.tip_sleep_desc), R.drawable.ic_sleep, R.color.sleep));
        healthTips.add(new HealthTip(getString(R.string.tip_fruits), getString(R.string.tip_fruits_desc), R.drawable.ic_food, R.color.success));
        healthTips.add(new HealthTip(getString(R.string.tip_checkup), getString(R.string.tip_checkup_desc), R.drawable.ic_health, R.color.info));
        healthTips.add(new HealthTip(getString(R.string.tip_heart), getString(R.string.tip_heart_desc), R.drawable.ic_heart, R.color.heart_rate));

        if (isGridView) {
            rvHealthTips.setLayoutManager(new GridLayoutManager(getContext(), 2));
        } else {
            rvHealthTips.setLayoutManager(new LinearLayoutManager(getContext()));
        }

        healthTipsAdapter = new HealthTipsAdapter(getContext(), healthTips, isGridView);
        rvHealthTips.setAdapter(healthTipsAdapter);
    }

    private void setupReminders() {
        rvReminders.setLayoutManager(new LinearLayoutManager(getContext()));
        loadReminders();
    }

    private void loadReminders() {
        List<Reminder> reminders = databaseHelper.getAllReminders(userId);

        if (reminders.isEmpty()) {
            tvNoReminders.setVisibility(View.VISIBLE);
            rvReminders.setVisibility(View.GONE);
        } else {
            tvNoReminders.setVisibility(View.GONE);
            rvReminders.setVisibility(View.VISIBLE);
            reminderAdapter = new ReminderAdapter(getContext(), reminders, new ReminderAdapter.OnReminderClickListener() {
                @Override
                public void onEdit(Reminder reminder) {
                    showEditReminderDialog(reminder);
                }

                @Override
                public void onDelete(Reminder reminder) {
                    showDeleteConfirmation(reminder);
                }
            });
            rvReminders.setAdapter(reminderAdapter);
        }
    }

    private void showAddReminderDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_reminder, null);

        EditText etTitle = dialogView.findViewById(R.id.etReminderTitle);
        EditText etDescription = dialogView.findViewById(R.id.etReminderDescription);
        EditText etDate = dialogView.findViewById(R.id.etReminderDate);
        EditText etTime = dialogView.findViewById(R.id.etReminderTime);

        // Date picker
        etDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(getContext(), (view, year, month, dayOfMonth) -> {
                etDate.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        // Time picker
        etTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                etTime.setText(String.format("%02d:%02d", hourOfDay, minute));
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
        });

        builder.setView(dialogView)
                .setTitle(R.string.add_reminder)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String description = etDescription.getText().toString().trim();
                    String date = etDate.getText().toString().trim();
                    String time = etTime.getText().toString().trim();

                    if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
                        Toast.makeText(getContext(), R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Reminder reminder = new Reminder(title, description, date, time);
                    boolean success = databaseHelper.addReminder(reminder, userId);
                    if (success) {
                        Toast.makeText(getContext(), R.string.success_save, Toast.LENGTH_SHORT).show();
                        loadReminders();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showEditReminderDialog(Reminder reminder) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_reminder, null);

        EditText etTitle = dialogView.findViewById(R.id.etReminderTitle);
        EditText etDescription = dialogView.findViewById(R.id.etReminderDescription);
        EditText etDate = dialogView.findViewById(R.id.etReminderDate);
        EditText etTime = dialogView.findViewById(R.id.etReminderTime);

        etTitle.setText(reminder.getTitle());
        etDescription.setText(reminder.getDescription());
        etDate.setText(reminder.getDate());
        etTime.setText(reminder.getTime());

        etDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(getContext(), (view, year, month, dayOfMonth) -> {
                etDate.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        etTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                etTime.setText(String.format("%02d:%02d", hourOfDay, minute));
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
        });

        builder.setView(dialogView)
                .setTitle(R.string.edit_reminder)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    reminder.setTitle(etTitle.getText().toString().trim());
                    reminder.setDescription(etDescription.getText().toString().trim());
                    reminder.setDate(etDate.getText().toString().trim());
                    reminder.setTime(etTime.getText().toString().trim());

                    boolean success = databaseHelper.updateReminder(reminder);
                    if (success) {
                        Toast.makeText(getContext(), R.string.success_save, Toast.LENGTH_SHORT).show();
                        loadReminders();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showDeleteConfirmation(Reminder reminder) {
        new AlertDialog.Builder(getContext())
                .setTitle(R.string.delete_reminder)
                .setMessage(R.string.confirm_delete)
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    boolean success = databaseHelper.deleteReminder(reminder.getId());
                    if (success) {
                        Toast.makeText(getContext(), "Pengingat berhasil dihapus", Toast.LENGTH_SHORT).show();
                        loadReminders();
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }
}