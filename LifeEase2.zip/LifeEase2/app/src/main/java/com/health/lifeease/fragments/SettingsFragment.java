package com.health.lifeease.fragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import com.health.lifeease.R;
import com.health.lifeease.activities.LoginActivity;
import com.health.lifeease.activities.NotificationSettingsActivity;
import com.health.lifeease.utils.DatabaseHelper;

import static android.content.Context.MODE_PRIVATE;

public class SettingsFragment extends Fragment {

    private TextView tvProfileUsername;
    private CardView cardChangeUsername, cardChangePassword, cardNotifications;
    private Button btnLogout;
    private DatabaseHelper databaseHelper;
    private SharedPreferences sharedPreferences;
    private int userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        // Inisialisasi
        databaseHelper = new DatabaseHelper(getContext());
        sharedPreferences = getActivity().getSharedPreferences("LifeEasePrefs", MODE_PRIVATE);
        userId = sharedPreferences.getInt("userId", -1);

        // Inisialisasi views
        tvProfileUsername = view.findViewById(R.id.tvProfileUsername);
        cardChangeUsername = view.findViewById(R.id.cardChangeUsername);
        cardChangePassword = view.findViewById(R.id.cardChangePassword);
        cardNotifications = view.findViewById(R.id.cardNotifications);
        btnLogout = view.findViewById(R.id.btnLogout);

        // Set username
        tvProfileUsername.setText(sharedPreferences.getString("username", "User"));

        // Change username click
        cardChangeUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChangeUsernameDialog();
            }
        });

        // Change password click
        cardChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChangePasswordDialog();
            }
        });

        // Notifications click
        cardNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), NotificationSettingsActivity.class);
                startActivity(intent);
            }
        });

        // Logout click
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogoutConfirmation();
            }
        });

        return view;
    }

    private void showChangeUsernameDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_change_username, null);

        EditText etNewUsername = dialogView.findViewById(R.id.etNewUsername);
        etNewUsername.setText(sharedPreferences.getString("username", ""));

        builder.setView(dialogView)
                .setTitle(R.string.change_username)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String newUsername = etNewUsername.getText().toString().trim();

                    if (newUsername.isEmpty()) {
                        Toast.makeText(getContext(), R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean success = databaseHelper.updateUsername(userId, newUsername);
                    if (success) {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("username", newUsername);
                        editor.apply();

                        tvProfileUsername.setText(newUsername);
                        Toast.makeText(getContext(), R.string.success_save, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Username sudah digunakan", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showChangePasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_change_password, null);

        EditText etOldPassword = dialogView.findViewById(R.id.etOldPassword);
        EditText etNewPassword = dialogView.findViewById(R.id.etNewPassword);
        EditText etConfirmPassword = dialogView.findViewById(R.id.etConfirmPassword);

        builder.setView(dialogView)
                .setTitle(R.string.change_password)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String oldPassword = etOldPassword.getText().toString().trim();
                    String newPassword = etNewPassword.getText().toString().trim();
                    String confirmPassword = etConfirmPassword.getText().toString().trim();

                    if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                        Toast.makeText(getContext(), R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!newPassword.equals(confirmPassword)) {
                        Toast.makeText(getContext(), R.string.error_password_mismatch, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (newPassword.length() < 6) {
                        Toast.makeText(getContext(), "Password minimal 6 karakter", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean success = databaseHelper.updatePassword(userId, newPassword);
                    if (success) {
                        Toast.makeText(getContext(), R.string.success_save, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Gagal mengubah password", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(getContext())
                .setTitle(R.string.logout)
                .setMessage("Apakah Anda yakin ingin keluar?")
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    // Clear shared preferences
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.clear();
                    editor.apply();

                    // Navigate to login
                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    getActivity().finish();
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }
}