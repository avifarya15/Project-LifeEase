package com.health.lifeease.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.health.lifeease.models.Reminder;
import com.health.lifeease.models.User;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "lifeease.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASSWORD = "password";

    // Reminder Table
    private static final String TABLE_REMINDERS = "reminders";
    private static final String COL_REMINDER_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_DATE = "date";
    private static final String COL_TIME = "time";
    private static final String COL_IS_ACTIVE = "is_active";
    private static final String COL_USER_ID_FK = "user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COL_EMAIL + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUsersTable);

        // Create Reminders Table
        String createRemindersTable = "CREATE TABLE " + TABLE_REMINDERS + " (" +
                COL_REMINDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TITLE + " TEXT NOT NULL, " +
                COL_DESCRIPTION + " TEXT, " +
                COL_DATE + " TEXT NOT NULL, " +
                COL_TIME + " TEXT NOT NULL, " +
                COL_IS_ACTIVE + " INTEGER DEFAULT 1, " +
                COL_USER_ID_FK + " INTEGER, " +
                "FOREIGN KEY(" + COL_USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "))";
        db.execSQL(createRemindersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REMINDERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // User Operations
    public boolean addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, user.getUsername());
        values.put(COL_EMAIL, user.getEmail());
        values.put(COL_PASSWORD, user.getPassword());

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public User loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COL_USER_ID, COL_USERNAME, COL_EMAIL, COL_PASSWORD},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3)
            );
            cursor.close();
            return user;
        }
        return null;
    }

    public boolean updateUsername(int userId, String newUsername) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, newUsername);

        int result = db.update(TABLE_USERS, values, COL_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        return result > 0;
    }

    public boolean updatePassword(int userId, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PASSWORD, newPassword);

        int result = db.update(TABLE_USERS, values, COL_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        return result > 0;
    }

    // Reminder Operations
    public boolean addReminder(Reminder reminder, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, reminder.getTitle());
        values.put(COL_DESCRIPTION, reminder.getDescription());
        values.put(COL_DATE, reminder.getDate());
        values.put(COL_TIME, reminder.getTime());
        values.put(COL_IS_ACTIVE, reminder.isActive() ? 1 : 0);
        values.put(COL_USER_ID_FK, userId);

        long result = db.insert(TABLE_REMINDERS, null, values);
        return result != -1;
    }

    public List<Reminder> getAllReminders(int userId) {
        List<Reminder> reminders = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_REMINDERS,
                new String[]{COL_REMINDER_ID, COL_TITLE, COL_DESCRIPTION, COL_DATE, COL_TIME, COL_IS_ACTIVE},
                COL_USER_ID_FK + "=?",
                new String[]{String.valueOf(userId)},
                null, null, COL_DATE + " ASC, " + COL_TIME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                Reminder reminder = new Reminder(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getInt(5) == 1
                );
                reminders.add(reminder);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return reminders;
    }

    public boolean updateReminder(Reminder reminder) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, reminder.getTitle());
        values.put(COL_DESCRIPTION, reminder.getDescription());
        values.put(COL_DATE, reminder.getDate());
        values.put(COL_TIME, reminder.getTime());
        values.put(COL_IS_ACTIVE, reminder.isActive() ? 1 : 0);

        int result = db.update(TABLE_REMINDERS, values, COL_REMINDER_ID + "=?",
                new String[]{String.valueOf(reminder.getId())});
        return result > 0;
    }

    public boolean deleteReminder(int reminderId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_REMINDERS, COL_REMINDER_ID + "=?",
                new String[]{String.valueOf(reminderId)});
        return result > 0;
    }
}