package com.health.lifeease.utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.health.lifeease.R;
import com.health.lifeease.activities.MainActivity;

public class NotificationHelper {

    private static final String CHANNEL_ID = "lifeease_reminder_channel";
    private static final String CHANNEL_NAME = "Pengingat Kesehatan";
    private static final String CHANNEL_DESC = "Notifikasi untuk pengingat aktivitas kesehatan";

    private Context context;
    private NotificationManager notificationManager;

    public NotificationHelper(Context context) {
        this.context = context;
        this.notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    // Buat Notification Channel (wajib untuk Android 8.0+)
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(CHANNEL_DESC);
            channel.enableVibration(true);
            channel.setShowBadge(true);

            notificationManager.createNotificationChannel(channel);
        }
    }

    // Kirim notifikasi pengingat
    public void sendReminderNotification(int notificationId, String title, String message) {
        // Intent untuk membuka aplikasi saat notifikasi diklik
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Build notifikasi
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setVibrate(new long[]{1000, 1000, 1000})
                .setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI);

        // Tampilkan notifikasi
        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(context);
        notificationManagerCompat.notify(notificationId, builder.build());
    }

    // Kirim notifikasi untuk tips kesehatan harian
    public void sendDailyHealthTip(String tip) {
        sendReminderNotification(
                1000,
                "Tips Kesehatan Hari Ini",
                tip
        );
    }

    // Kirim notifikasi minum air
    public void sendWaterReminder() {
        sendReminderNotification(
                1001,
                "💧 Waktunya Minum Air!",
                "Jangan lupa minum air putih untuk menjaga hidrasi tubuh Anda."
        );
    }

    // Kirim notifikasi olahraga
    public void sendExerciseReminder() {
        sendReminderNotification(
                1002,
                "🏃 Waktunya Berolahraga!",
                "Luangkan waktu 30 menit untuk berolahraga hari ini."
        );
    }

    // Batalkan notifikasi tertentu
    public void cancelNotification(int notificationId) {
        notificationManager.cancel(notificationId);
    }

    // Batalkan semua notifikasi
    public void cancelAllNotifications() {
        notificationManager.cancelAll();
    }
}