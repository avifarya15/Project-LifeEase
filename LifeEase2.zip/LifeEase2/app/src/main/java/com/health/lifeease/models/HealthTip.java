package com.health.lifeease.models;

public class HealthTip {
    private int id;
    private String title;
    private String description;
    private int iconResource;
    private int colorResource;

    // Constructor
    public HealthTip() {}

    public HealthTip(String title, String description, int iconResource, int colorResource) {
        this.title = title;
        this.description = description;
        this.iconResource = iconResource;
        this.colorResource = colorResource;
    }

    public HealthTip(int id, String title, String description, int iconResource, int colorResource) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.iconResource = iconResource;
        this.colorResource = colorResource;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getIconResource() {
        return iconResource;
    }

    public int getColorResource() {
        return colorResource;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setIconResource(int iconResource) {
        this.iconResource = iconResource;
    }

    public void setColorResource(int colorResource) {
        this.colorResource = colorResource;
    }
}