package com.health.lifeease.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.health.lifeease.R;
import com.health.lifeease.models.HealthTip;

import java.util.List;

public class HealthTipsAdapter extends RecyclerView.Adapter<HealthTipsAdapter.ViewHolder> {

    private Context context;
    private List<HealthTip> healthTips;
    private boolean isGridView;

    public HealthTipsAdapter(Context context, List<HealthTip> healthTips, boolean isGridView) {
        this.context = context;
        this.healthTips = healthTips;
        this.isGridView = isGridView;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layoutId = isGridView ? R.layout.item_health_tip_grid : R.layout.item_health_tip_list;
        View view = LayoutInflater.from(context).inflate(layoutId, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HealthTip healthTip = healthTips.get(position);

        holder.tvTitle.setText(healthTip.getTitle());
        holder.tvDescription.setText(healthTip.getDescription());
        holder.ivIcon.setImageResource(healthTip.getIconResource());

        // Set background color
        int color = ContextCompat.getColor(context, healthTip.getColorResource());
        holder.ivIcon.setColorFilter(color);

        if (!isGridView) {
            holder.cardView.setCardBackgroundColor(adjustAlpha(color, 0.1f));
        }
    }

    @Override
    public int getItemCount() {
        return healthTips.size();
    }

    private int adjustAlpha(int color, float factor) {
        int alpha = Math.round(255 * factor);
        int red = android.graphics.Color.red(color);
        int green = android.graphics.Color.green(color);
        int blue = android.graphics.Color.blue(color);
        return android.graphics.Color.argb(alpha, red, green, blue);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView ivIcon;
        TextView tvTitle, tvDescription;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            ivIcon = itemView.findViewById(R.id.ivIcon);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
        }
    }
}