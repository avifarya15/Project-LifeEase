package com.health.lifeease.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.health.lifeease.R;
import com.health.lifeease.fragments.HomeFragment;
import com.health.lifeease.fragments.SettingsFragment;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigation;
    private TextView tvToolbarTitle;
    private ImageView ivNotification;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi SharedPreferences
        sharedPreferences = getSharedPreferences("LifeEasePrefs", MODE_PRIVATE);

        // Inisialisasi views
        tvToolbarTitle = findViewById(R.id.tvToolbarTitle);
        ivNotification = findViewById(R.id.ivNotification);
        bottomNavigation = findViewById(R.id.bottomNavigation);

        // Set default fragment
        loadFragment(new HomeFragment());
        tvToolbarTitle.setText(R.string.home);

        // Bottom navigation listener
        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                String title = "";

                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    fragment = new HomeFragment();
                    title = getString(R.string.home);
                } else if (itemId == R.id.nav_settings) {
                    fragment = new SettingsFragment();
                    title = getString(R.string.settings);
                }

                if (fragment != null) {
                    loadFragment(fragment);
                    tvToolbarTitle.setText(title);
                    return true;
                }
                return false;
            }
        });

        // Notification icon click
        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Fitur notifikasi akan segera hadir", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainer, fragment);
        transaction.commit();
    }

    @Override
    public void onBackPressed() {
        // Cek apakah fragment yang aktif adalah HomeFragment
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragmentContainer);
        if (currentFragment instanceof HomeFragment) {
            // Jika di Home, keluar dari aplikasi
            super.onBackPressed();
        } else {
            // Jika bukan di Home, kembali ke Home
            bottomNavigation.setSelectedItemId(R.id.nav_home);
        }
    }
}