package com.health.lifeease.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {

    private static final String TAG = "AlarmReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        // Ambil data dari intent
        int reminderId = intent.getIntExtra("reminder_id", 0);
        String title = intent.getStringExtra("title");
        String message = intent.getStringExtra("message");

        Log.d(TAG, "Alarm received for: " + title);

        // Kirim notifikasi
        NotificationHelper notificationHelper = new NotificationHelper(context);
        notificationHelper.sendReminderNotification(reminderId, title, message);
    }
}