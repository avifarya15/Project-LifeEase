package com.health.lifeease.models;

public class Reminder {
    private int id;
    private String title;
    private String description;
    private String date;
    private String time;
    private boolean isActive;

    // Constructor
    public Reminder() {}

    public Reminder(String title, String description, String date, String time) {
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.isActive = true;
    }

    public Reminder(int id, String title, String description, String date, String time, boolean isActive) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.isActive = isActive;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public boolean isActive() {
        return isActive;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}