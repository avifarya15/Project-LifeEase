package com.health.lifeease.activities;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.health.lifeease.R;
import com.health.lifeease.utils.AlarmScheduler;
import com.health.lifeease.utils.NotificationHelper;

public class NotificationSettingsActivity extends AppCompatActivity {

    private static final int NOTIFICATION_PERMISSION_CODE = 100;

    private Toolbar toolbar;
    private SwitchCompat switchDailyTip, switchWaterReminder;
    private Button btnTestNotification;
    private SharedPreferences sharedPreferences;
    private AlarmScheduler alarmScheduler;
    private NotificationHelper notificationHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        // Inisialisasi
        sharedPreferences = getSharedPreferences("LifeEasePrefs", MODE_PRIVATE);
        alarmScheduler = new AlarmScheduler(this);
        notificationHelper = new NotificationHelper(this);

        // Setup toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Inisialisasi views
        switchDailyTip = findViewById(R.id.switchDailyTip);
        switchWaterReminder = findViewById(R.id.switchWaterReminder);
        btnTestNotification = findViewById(R.id.btnTestNotification);

        // Check notification permission
        checkNotificationPermission();

        // Load saved preferences
        loadNotificationPreferences();

        // Daily Tip Switch
        switchDailyTip.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                alarmScheduler.scheduleDailyHealthTip();
                Toast.makeText(this, "Tips kesehatan harian diaktifkan", Toast.LENGTH_SHORT).show();
            } else {
                alarmScheduler.cancelDailyReminders();
                Toast.makeText(this, "Tips kesehatan harian dinonaktifkan", Toast.LENGTH_SHORT).show();
            }
            saveNotificationPreference("daily_tip_enabled", isChecked);
        });

        // Water Reminder Switch
        switchWaterReminder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                alarmScheduler.scheduleWaterReminder();
                Toast.makeText(this, "Pengingat minum air diaktifkan", Toast.LENGTH_SHORT).show();
            } else {
                alarmScheduler.cancelDailyReminders();
                Toast.makeText(this, "Pengingat minum air dinonaktifkan", Toast.LENGTH_SHORT).show();
            }
            saveNotificationPreference("water_reminder_enabled", isChecked);
        });

        // Test Notification Button
        btnTestNotification.setOnClickListener(v -> {
            notificationHelper.sendReminderNotification(
                    12345,
                    "🎉 Test Notifikasi",
                    "Notifikasi berfungsi dengan baik! LifeEase siap mengingatkan aktivitas kesehatan Anda."
            );
            Toast.makeText(this, "Test notifikasi dikirim!", Toast.LENGTH_SHORT).show();
        });
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_CODE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Izin notifikasi diberikan", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Izin notifikasi ditolak. Notifikasi tidak akan berfungsi.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void loadNotificationPreferences() {
        boolean dailyTipEnabled = sharedPreferences.getBoolean("daily_tip_enabled", false);
        boolean waterReminderEnabled = sharedPreferences.getBoolean("water_reminder_enabled", false);

        switchDailyTip.setChecked(dailyTipEnabled);
        switchWaterReminder.setChecked(waterReminderEnabled);
    }

    private void saveNotificationPreference(String key, boolean value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }
}